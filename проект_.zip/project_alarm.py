import sys
import sqlite3
import pygame
import easygui
import datetime as dt
from PyQt5 import uic
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QTableWidget, QSpinBox, QTableWidgetItem, QMainWindow, QComboBox, QApplication, QPushButton, QLabel, QTextEdit



class Alarm(QMainWindow):
    def __init__(self):
        pygame.init()
        super().__init__()
        uic.loadUi('alarm.ui', self)
        self.choose_ringtone.clicked.connect(self.select)
        self.confirm.clicked.connect(self.add_alarm)

        self.con = sqlite3.connect('project_ringtones.sqlite')
        self.cur = self.con.cursor()
        self.table_update()
        self.alarm_name.setText(f'Будильник_{len(self.result)}')

    def table_update(self):
        self.result = self.cur.execute("""select * from start order by id""").fetchall()
        self.table.setRowCount(len(self.result))
        for i, elem in enumerate(self.result):
            for j, val in enumerate(elem):
                if j != 0:
                    a = QTableWidgetItem(str(val))
                    self.table.setItem(i, j - 1, a)

    def add_alarm(self):
        if self.alarm_name.text() == '' or self.ringtone_name.text() == '':
            self.label_6.setText('Заполните все поля')
            self.label_6.show()
        else:
            row = []
            name = self.alarm_name.text()
            text = str(self.hours.value()).rjust(2, '0') + ':' + str(self.minutes.value()).rjust(2, '0')
            al_time = dt.datetime.strptime(text, '%H:%M').time()
            ringtone = self.ringtone_name.text()
            repeat = self.repeat_ask.currentText()
            row.append(name)
            row.append(al_time)
            row.append(repeat)
            row.append(ringtone)
            row.append(repeat)
            self.cur.execute(f"""insert into start(alarm_name, alarm_time, sound, alarm_repeat, song_path)
                        values ('{name}', '{al_time}', '{ringtone}', '{repeat}', '{self.song_path}')""")
            self.con.commit()
            self.table_update()

            setattr(self, f'tmr_{self.result[-1][0]}', QTimer(self))
            getattr(self, f'tmr_{self.result[-1][0]}').setInterval(60000)
            setattr(self, f'k_{self.result[-1][0]}', str(self))
            getattr(self, f'tmr_{self.result[-1][0]}').timeout.connect(self.run)
            getattr(self, f'tmr_{self.result[-1][0]}').start()
            
    def run(self):
        f = 0
        name = f'k_{self.result[-1][0]}'
        a = int(name.split('_')[-1])
        print(a)
        al = self.cur.execute(f"""select alarm_time from start
                        where id = {a}""").fetchone()
        al = al[0]
        print(al)
        al = ':'.join(str(al).split(':')[:-1])
        print(al)
        rep = self.cur.execute(f"""select alarm_repeat from start
                        where id = {a}
                        order by id""").fetchone()[0]
        al_t = ':'.join(str(al).split(':')[:2])
        rn = ':'.join(str(dt.datetime.now().time()).split(':')[:2])
        print(name)
        print(al)
        print(rep)
        print(al_t)
        print(rn)
        if rep == 'Однократно':
            if al_t == rn:
                f = 1
        elif rep == 'По будням':
            days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
            if dt.datetime.now().strftime('%A') in days and al_t == rn:
                f = 1
        elif rep == 'Ежедневно':
            if al_t == rn:
                f = 1
        if f == 1:
            path = self.cur.execute(f"""select song_path from start
                                    where id = {a}""").fetchone()[0]
            sound = pygame.mixer.Sound(path)
            sound.play(-1)
        self.con.commit()

    def select(self):
        input_file = easygui.fileopenbox(default="рингтоны/*.mp3", filetypes=["*.mp3"])
        self.song = pygame.mixer.Sound(input_file)
        self.song_path = input_file
        self.ringtone_name.setText(input_file.split('\\')[-1])

    def a_main():
        if __name__ == '__main__':
            app = QApplication(sys.argv)
            al = Alarm()
            al.show()
            sys.exit(app.exec())