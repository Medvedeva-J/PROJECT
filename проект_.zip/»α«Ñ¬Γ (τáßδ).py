import sys
import datetime as dt
from project_timer import Timer
from project_alarm import Alarm
from PyQt5.QtWidgets import QCalendarWidget, QMainWindow, QApplication, QPushButton, QLabel
from PyQt5 import uic
from PyQt5.QtCore import QTimer


class Watch(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('clocks.ui', self)
        self.tmr = QTimer(self)
        self.clock.setText(str(dt.datetime.now().time()).split('.')[0])
        self.btn_alarm.clicked.connect(self.alarm)
        #self.btn_stopwatch.clicked.connect(self.stopwatch)
        #self.btn_timer.clicked.connect(self.timer)
        self.tmr.setInterval(1000)
        self.tmr.timeout.connect(self.run)
        self.tmr.start()

    def alarm(self):
        Alarm.a_main()

    def run(self):
        self.clock.setText(str(dt.datetime.now().time()).split('.')[0])
        self.clock.repaint()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = Watch()
    w.show()
    sys.exit(app.exec())